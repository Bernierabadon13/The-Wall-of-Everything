# The Wall of Everything

> Some things are easier to write than to say.

A peaceful 3D world with one giant public wall. Walk across a golden grass field at sunset, choose an empty spot on the wall, and leave something you never said. Your words appear exactly where you clicked, and fade away after 7 days.

Created and directed by **Bernie Rabadon**. See [AUTHORSHIP.md](AUTHORSHIP.md) for how it was made.

## Features
- First-person 3D world built with Three.js: walk, look, sprint, zoom
- Click anywhere on the wall: a raycaster finds the exact spot and saves it as wall coordinates (u, v), so every message reappears where it was written
- Type a confession (max 200 characters) or write it by hand on a pad
- Five writing styles (marker, chalk, spray paint, pen, graffiti), six handwriting fonts, eight colors, three sizes
- Live preview on the wall that blocks overlapping messages
- Click a message: it glows and the author's name bounces up and fades
- Messages expire after 7 days
- Human check (captcha), hidden bot trap and posting cooldown
- Dark golden sunset mood, swaying grass, circling birds that whistle back what you click, visible wind
- Synthesized sound (no audio files): bird calls and wind, press M to mute

## Controls
| Desktop | Action |
|---|---|
| W A S D | Walk |
| Mouse | Look (drag if the mouse is not captured) |
| Shift | Sprint |
| Scroll | Zoom |
| Click | Choose a spot / read a message |
| Esc | Release the mouse |
| M | Sound on or off |

Mobile: left thumb walks, drag to look, pinch to zoom, tap the wall.

## Run it
It is one static file. Open `index.html` in Chrome or Edge, or serve the folder:

```bash
python -m http.server 8000   # then open http://localhost:8000
```

It needs an internet connection for Three.js (r128, cdnjs) and Google Fonts.

## Deploy on Vercel
Step by step: [docs/DEPLOY-VERCEL.md](docs/DEPLOY-VERCEL.md).

## Deploy on GitHub Pages
1. Push this repo to GitHub.
2. Settings -> Pages -> Deploy from a branch -> `main` / root.
3. Your site will be at `https://<your-username>.github.io/<repo-name>/`.

## Saving and sharing messages (no database needed)
Messages are saved in each visitor's browser by default. To share one wall between everyone you can use a plain `messages.json` file in this repo, or a free Google Sheet. Step by step: [docs/SHARED-STORAGE.md](docs/SHARED-STORAGE.md).

## Known limits (and next steps)
- By default messages are saved **per browser**. Sharing uses `messages.json` or a Google Sheet (see above). For real-time sharing at scale, the next step is Supabase (PostgreSQL + Realtime + Auth) with row-level security.
- The captcha is a browser-side gate. Real protection needs a server check (for example Cloudflare Turnstile verified in a Supabase Edge Function) plus rate limiting.
- Planned: rewrite in React + Vite + TypeScript, moderation queue, reporting, categories and search.

## Tech
HTML, CSS and JavaScript in one file. Three.js r128. Web Audio API. Canvas 2D for the wall texture.

## License
MIT. See [LICENSE](LICENSE).
