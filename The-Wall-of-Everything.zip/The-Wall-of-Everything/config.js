// Settings for The Wall of Everything.
// To share messages between all visitors, paste your Google Apps Script web app link
// (it ends in /exec) between the quotes below. Leave it empty to save only in each browser.
window.WOE_CONFIG = {
  SHARED_URL: ""
};
