# Authorship

**Concept, art direction and every product decision: Bernie Rabadon.**
**Code written with Claude (Anthropic) as a coding assistant**, in a long chat that ran over November 2026. Bernie wrote the specifications, reviewed each version, tested it, and sent back corrections until it matched the vision.

## What Bernie decided
- The idea: a public confession wall where people leave what they could not say, called THE WALL OF EVERYTHING, with the tagline "Some things are easier to write than to say."
- The full project specification (features, database design, phases, security and privacy rules).
- The look: wall resembling a real graffiti wall, rainbow graffiti, bond-paper form with creases and wind animation, a marquee of feelings, a one-line title printed into the wall.
- The rules: 200-character limit, 7-day expiry, captcha on submit, anonymous option, handwriting by hand.
- The 3D direction: a first-person Roblox-style world, one giant wall in the middle, click-to-place with a raycaster and saved coordinates, no trees, grass-covered far hills.
- The mood: a darker, warmer, sad golden sunset based on a reference photo, same-height crowded grass, visible wind, birds that imitate sound.
- The guide screen: "Made by Bernie" and the trivia about why there is no jump button.
- The testing: reported flicker, unresponsive clicks and the guide that would not close, which drove fixes.

## What Claude did
Wrote and revised the code to Bernie's instructions, and explained choices and limits.

## Evidence to keep with this repo
- Your original specification documents: save them in `docs/` (for example `docs/original-spec-2d.md` and `docs/original-spec-3d.md`).
- Your reference images and notes (do not commit images you do not have rights to; credit their sources instead).
- An export or screenshots of the chat.
- The git history: commit under your own account, with your own name and email, so every change is timestamped to you.
