// Google Apps Script, no Google Sheet needed.
// Messages are stored inside this script (Script Properties). Nothing to connect, no permissions to fight with.
const WEEK = 7 * 864e5, MAX_MSGS = 600;

function all_() {
  const p = PropertiesService.getScriptProperties().getProperties(), out = [];
  for (const k in p) {
    if (k.indexOf("m:") !== 0) continue;
    try { out.push({ k: k, o: JSON.parse(p[k]) }); } catch (e) {}
  }
  return out;
}

// Everyone's browser reads the last 7 days of messages from here.
function doGet() {
  const since = Date.now() - WEEK;
  return ContentService
    .createTextOutput(JSON.stringify(all_().filter(x => x.o.t > since).map(x => x.o)))
    .setMimeType(ContentService.MimeType.JSON);
}

// New messages arrive here. Basic checks; the page re-validates everything it reads.
function doPost(e) {
  try {
    const raw = e.postData.contents;
    if (raw.length > 8500) throw new Error("too big");
    const o = JSON.parse(raw);
    if (!o || typeof o.text !== "string" || o.text.length > 200 || String(o.name || "").length > 30 || !(o.t > 0)) throw new Error("bad");
    const props = PropertiesService.getScriptProperties(), list = all_(), since = Date.now() - WEEK;
    list.filter(x => x.o.t < since).forEach(x => props.deleteProperty(x.k));          // drop expired
    const keep = list.filter(x => x.o.t >= since).sort((a, b) => a.o.t - b.o.t);
    while (keep.length >= MAX_MSGS) props.deleteProperty(keep.shift().k);              // drop oldest if full
    props.setProperty("m:" + o.t + ":" + String(o.id || "").slice(0, 20), JSON.stringify(o));
  } catch (err) {}
  return ContentService.createTextOutput("ok");
}
