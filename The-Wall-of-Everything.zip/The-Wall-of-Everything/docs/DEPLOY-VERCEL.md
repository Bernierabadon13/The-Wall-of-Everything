# Publish on Vercel (free)

The project is one static site (`index.html`), so there is nothing to build.

## Before you deploy: turn on shared messages
1. Follow `docs/SHARED-STORAGE.md` and paste your Google Apps Script link into `config.js`.
2. Test the link: open it in a browser tab. It should show `[]` (an empty list) or your messages.

## Option A: with GitHub (recommended, updates automatically)
1. Create an empty repo on github.com and push this folder to it.
2. Go to vercel.com and sign up with your GitHub account.
3. Add New -> Project -> import your repo.
4. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Root Directory: `./`.
5. Click **Deploy**. In about 30 seconds you get `https://your-project.vercel.app`.
6. Every time you push to `main`, Vercel redeploys by itself.

## Option B: from your computer
```bash
npm i -g vercel
cd The-Wall-of-Everything
vercel          # first run: log in and answer the questions (framework: Other)
vercel --prod   # publish to the live URL
```

## Custom domain (optional)
Project -> Settings -> Domains -> add your domain and follow the DNS steps.

## Checklist after deploying
- Page loads and "Press Enter or click to enter" works.
- You can walk, look, and click the wall to open the writing panel.
- Post a message, then open the site in another browser or a phone: it shows up within about 15 seconds.
- Sound works after you enter (M mutes).

## If something is wrong
- Blank screen: your network blocks cdnjs (Three.js) or WebGL is off. Try Chrome or Edge with graphics acceleration on.
- Messages do not show for others: `SHARED_URL` is empty, the Apps Script is not deployed as "Anyone", or you changed the script without choosing Deploy -> Manage deployments -> New version.
- Message cannot be posted: the captcha was not verified, or you posted less than 10 seconds ago.
