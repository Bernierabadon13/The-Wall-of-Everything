# Saving and sharing messages without a database

There are three ways, from simplest to most live. You can combine them.

## 1. Your own browser (already on)
Every message is saved in the visitor's browser (localStorage) and fades after 7 days. Nobody else sees it.

## 2. A file in the repo: `messages.json` (free, manual)
1. Open the live site, click the download button (top right, next to the speaker) to save `messages.json`.
2. Replace `messages.json` in this repo with that file, commit and push.
3. Everyone who opens the site now sees those messages. Messages older than 7 days disappear automatically.

You choose what goes in, so it is also your moderation.

## 3. A Google Sheet (free, live, no server)
1. Create a new Google Sheet.
2. Extensions -> Apps Script. Delete the sample code and paste `docs/apps-script/Code.gs`. Save.
3. Deploy -> New deployment -> type **Web app**. Execute as: **Me**. Who has access: **Anyone**. Deploy and authorize.
4. Copy the web app URL (ends in `/exec`).
5. Open `config.js` (a tiny file next to `index.html`), paste the link between the quotes after `SHARED_URL:`, save, and push.

Now new messages are posted to the sheet and every visitor reloads the shared list every 15 seconds. To remove a bad message, delete its row in the sheet. Keep the sheet private to you.

Limits: anyone can post to the URL (the page checks and ignores invalid data), Google can rate-limit very busy sites, and updates take up to 15 seconds. When the wall gets big, move to Supabase.

## Easiest version: no Sheet at all
If the Sheet version gives permission errors, use `docs/apps-script/Code-no-sheet.gs` instead. Create a new project at script.google.com, paste that file, deploy it as a Web app (Execute as: Me, Who has access: Anyone) and use the `/exec` link in `config.js`. To remove a bad message: Project Settings (gear icon) -> Script Properties -> delete its row.
