# Complete setup guide (after `doGet` runs without an error)

## Part 1. Publish the Google script
1. In Apps Script, click **Deploy** -> **New deployment**. Click the gear next to "Select type" -> **Web app**.
2. Execute as: **Me**. Who has access: **Anyone**. Click **Deploy**.
   (If you already deployed once: Deploy -> Manage deployments -> pencil -> Version: **New version** -> Deploy.)
3. If asked, click **Authorize access**, pick your account, then **Advanced** -> **Go to (project) (unsafe)** -> **Allow**.
4. Copy the **Web app URL**. It starts with `https://script.google.com/macros/s/` and ends with `/exec`.
5. Open that URL in an incognito window. You should see `[]`.

## Part 2. Put the link in `config.js`
1. Unzip the project. Open `config.js` in Notepad.
2. Paste the URL between the quotes: `SHARED_URL: "https://script.google.com/macros/s/.../exec"`
3. Save. (If you use Save as, choose "All files" and name it exactly `config.js`.)

## Part 3. Put the project on GitHub (no commands needed)
1. Go to github.com, sign in, click **New repository**. Name it `the-wall-of-everything`, choose **Public**, click **Create repository**.
2. Click **uploading an existing file**.
3. Open your unzipped folder and drag **everything inside it** (index.html, config.js, messages.json, vercel.json, README.md, LICENSE, AUTHORSHIP.md, docs folder) into the page.
4. Click **Commit changes**.

## Part 4. Publish on Vercel
1. Go to vercel.com -> **Sign up** -> **Continue with GitHub**.
2. **Add New** -> **Project** -> find `the-wall-of-everything` -> **Import**.
3. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.
4. In about 30 seconds you get a link like `https://the-wall-of-everything.vercel.app`. That is your public wall.

## Part 5. Test it
1. Open your Vercel link in Chrome or Edge. Press Enter. Walk to the wall (WASD + mouse).
2. Click an empty spot, write a message, press **Verify that you are human**, type the code, press **Leave it on the wall**.
3. Open the same link on your phone (or another browser). Your message should appear within about 15 seconds.
4. In Apps Script, open Project Settings (gear) -> Script Properties. You should see a row starting with `m:`. That is your message.

## Part 7. Day to day
- **Delete a bad message:** Apps Script -> Project Settings -> Script Properties -> delete its row.
- **Change the link later:** on GitHub open `config.js` -> pencil icon -> edit -> **Commit changes**. Vercel updates itself.
- **Change the script code:** edit, save, then Deploy -> Manage deployments -> pencil -> **New version** -> Deploy. Without this, the old code keeps running.
- Messages disappear after 7 days. The script keeps at most 600.

## If something is wrong
| Problem | Fix |
|---|---|
| Blank screen | Use Chrome or Edge, turn on graphics acceleration, check your internet (Three.js and fonts load online). |
| Others do not see my message | `config.js` link is empty or wrong, the deployment is not set to "Anyone", or you forgot "New version". |
| Google says "file cannot be opened" | Open the link in incognito, make sure it ends in `/exec`, use a personal @gmail.com account. |
| Cannot post | Verify you are human first, and wait 10 seconds between posts. |
